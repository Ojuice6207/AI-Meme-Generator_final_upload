import os
import json

# Path to template images
template_path = "templates"

# Define default text positions (You can update these later)
default_positions = {
    "top_text_position": [30, 20],
    "bottom_text_position": [30, 400]  # Adjust based on meme format
}

# Generate metadata
meme_list = []
for file in os.listdir(template_path):
    if file.endswith(".jpg") or file.endswith(".png"):
        meme_list.append({
            "name": file.replace("_", " ").split(".")[0],  # Remove underscore & extension
            "file": file,
            "top_text_position": default_positions["top_text_position"],
            "bottom_text_position": default_positions["bottom_text_position"]
        })

# Save to memes.json
with open("memes.json", "w") as f:
    json.dump(meme_list, f, indent=4)

print("✅ memes.json created successfully!")
