import requests
import os

# Step 1: Fetch Meme Templates from Imgflip API
response = requests.get("https://api.imgflip.com/get_memes")
if response.status_code == 200:
    memes = response.json()["data"]["memes"]
else:
    print("Failed to fetch memes.")
    memes = []

# Step 2: Create a folder to store templates
os.makedirs("templates", exist_ok=True)

# Step 3: Download and save top 50 meme templates with headers
headers = {
    "User-Agent": "Mozilla/5.0"  # Pretend to be a web browser
}

for meme in memes[:200]:  # Change the number if needed
    filename = f"templates/{meme['name'].replace(' ', '_')}.jpg"
    
    try:
        img_response = requests.get(meme["url"], headers=headers, stream=True)
        if img_response.status_code == 200:
            with open(filename, "wb") as file:
                for chunk in img_response.iter_content(1024):
                    file.write(chunk)
            print(f"✅ Saved: {filename}")
        else:
            print(f"❌ Failed to download: {meme['name']} (Status Code: {img_response.status_code})")

    except Exception as e:
        print(f"⚠️ Error downloading {meme['name']}: {e}")


